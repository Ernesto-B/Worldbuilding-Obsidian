---
date: 2025-01-21
campaign: 
arc: 
type: Faction
aliases: 
alingment: 
---
# Summary
- A darker faith among [[Stonefall]]'s lower [[Hollow]]s, emphasizing survival, ambition, and power through sacrifice. Shrines to the Hollow Flame burn deep within the city's labyrinthine alleys

# Leadership


# Appearance


# Lore


# Members