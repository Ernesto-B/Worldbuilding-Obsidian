---
date: 2025-01-15
campaign:
arc: 
type: location
aliases: 
---
# Lore
- A Hollow is the equivalent of a district in the city of [[Stonefall]] in the [[Coast of Iyresa]], which are separated by different layers of the cratered city.
- There are 5 Hollows, separated by economic class. The lower middle class lives on the first drift, which also spills onto the craters outskirts, while every subsequent economic class reside on lower layer, the poor being on the bottom level where light rarely reaches.