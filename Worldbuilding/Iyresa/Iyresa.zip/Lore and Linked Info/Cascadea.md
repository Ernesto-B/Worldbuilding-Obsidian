---
date: 2025-01-15
campaign:
arc: 
type: region or country
aliases: 
---
# Description
- Cascadea - a floating island - is the upper city in the country of [[Coast of Iyresa|Iyresa]].
- The city is surrounded by a magnetic field that came to be after a meteor struck the land. The magnetic field has benefitted the city in 2 ways: It wards off monsters, as well as allows individuals to travel up and down the island's inverse waterfalls.
- 

# Geographical Location and Features
- Cascadea is a floating island. The only way to enter the city is from the bottom of the island and utilizing special transport methods that take advantage of waterfalls that flow upwards.
- There are 5 inverse waterfalls that are affected by Cascadea's magentic field, dividing the city into 5 [[Drift|Drifts]], each serving a different purpose.
- 

# Lore


# Other Key Locations
- **Echoeside (Entertainment [[Drift]]):**
    - Echoeside, a bustling drift, is host to many of the top talent and entrepreneurs of the country. Streets are lined with concessions, shows, restaurants, and brothels.
    -  
- **Sagehaven (Scholar [[Drift]]):**
    - 
- **Eryndral (Government  [[Drift]]):**
    - 
- **Voltaryn (Energy [[Drift]]):**
    - 
- **Auralith (Market [[Drift]]):**
    - 

# History




# Detailed Notes
### Government Structure
* 

### Guilds
* 

### Social/Economic/Political Hierarchy (Class Structure)
* 

### Political/Social Ideology and Culture
* 

### Trade and Economics
* 

### Language and Naming
* 

### Religion
* 

### Magic
* 

### Legal System
* 

### Organized Crime
* 

### Education
* 

### Inter-racial relations
* 

### Music/Fashion/Food
* 

### Science, Medicine, and Technology
* 

### Military, Secret Services, Conflict
* 

### The Supernatural/Myths/Legends
* 

### Architecture/Civic Planning
* 

### Aging & Pregnancy
* 

### Marriage
* 

### Death, Funerals, and the Afterlife
* 

### Adventuring Hooks
* 