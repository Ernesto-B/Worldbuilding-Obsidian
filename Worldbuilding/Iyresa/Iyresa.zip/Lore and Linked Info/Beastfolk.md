---
date: 2025-01-18
campaign: 
arc: 
type: Faction
aliases: 
alingment: 
---
# Summary
- ==Native to Iyresa==?
- The Beast People specialize in hunting and combat. They tend to stray away from the use of magic and stick to their natural ability to get around. 
- They have heightened senses, such as sight, smell and hearing, to use to their advantages when hunting or when in combat. 
- Many professions among the race include being adventurers, working as security/police, taking up hunting and food distributors, as well as taking up teaching jobs in combat/military schools.


# Leadership


# Appearance


# Lore


# Members
```dataview
LIST
WHERE type = "NPC"
```