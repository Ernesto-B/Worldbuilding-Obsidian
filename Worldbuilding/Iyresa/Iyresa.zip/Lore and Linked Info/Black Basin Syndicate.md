---
date: 2025-01-19
campaign: 
arc: 
type: Faction
aliases: 
alingment: 
---
# Summary
- The Black Basin Syndicate is the most powerful and feared criminal organization in [[Stonefall]], operating primarily out of the lower [[Hollow|Hollows]]. It thrives on smuggling, illegal trading, and the notorious underground fighting ring known as the Pit of Despair. Ruthless, secretive, and highly organized, the Syndicate’s influence stretches from the Black Depths to the Sunlit Crown, exploiting the divisions and chaos of the city's layered society.
- In the Lower Hollows: The Syndicate rules with near-absolute authority. Residents of the Dimming Mire and Black Depths rely on the Syndicate for security, work, or smuggled goods, though this dependency often traps them in cycles of debt and exploitation.
- In the Upper Hollows: While less visible, the Syndicate’s reach extends into the Sunlit Crown and Azure Steps through corrupt officials, merchants, and wealthy patrons. They supply Cascadean luxury goods to Stonefall’s elite and use bribes to ensure their activities go unnoticed.

# Leadership


# Appearance


# Lore


# Members