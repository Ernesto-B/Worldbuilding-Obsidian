---
date: 2025-01-19
campaign: 
arc: 
type: location
aliases: 
---
# Description


# Location
- West of the major cities [[Cascadea]] & [[Stonefall]].

# Plot
- ==Reported sightings of humanoid like creatures in the caves have been rumoured but not investigated==. 

# Key Locations
- 

# History
- These ancient caves were formed unknowingly after the appearance of the massive crater that formed [[Stonefall]]. Nobody knows how they were formed, and many that have ventured deep into the caves did not return.
- Only the areas near the surface have been explored as the threat of dangerous monsters repels adventurers from venturing into the caves. 

### Adventuring Hooks
- ==Lost civilization lives here??==
- Hidden Treasure Room: A treasure map leads the adventurers to a seemingly impenetrable door within the cave, guarded by traps and riddles.
- Monstrous Lair: Adventurers accidentally disturb the lair of a powerful monster that begins to hunt them through the caves and eventually threatens to disturb the cities. 
- Portal to Another Country: In the deepest part of the cave lies a portal to another country, which may bring up questions about the history of the country and the motives of the people who use(d) the portal. 