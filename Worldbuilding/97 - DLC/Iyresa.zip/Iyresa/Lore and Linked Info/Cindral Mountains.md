---
date: 2025-01-21
campaign: 
arc: 
type: location
aliases: 
---
# Description
- 

# Location
- 

# Plot
- 

# Key Locations
-  

# History
- 

# Adventuring Hooks
- 