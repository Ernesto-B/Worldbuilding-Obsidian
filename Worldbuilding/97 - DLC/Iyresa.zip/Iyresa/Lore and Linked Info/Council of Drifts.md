---
date: 2025-01-21
campaign: 
arc: 
type: Faction
aliases: 
alingment: 
---
# Summary
- The Council of Drifts is the governing body of [[Cascadea]], comprising five representatives, each chosen from one of the city's five [[Drift]]s. Together, they oversee the city's administration, resolve disputes, and maintain its reputation as the pinnacle of luxury and entertainment. While the council is intended to act as a balanced and unified leadership, the wealth and power of its members often lead to political intrigue, rivalries, and hidden agendas.
- The council meets in a grand circular chamber located in the Silver Drift, with an enchanted skylight that projects a serene view of the lake above. Discussions are moderated by the Silver Drift Representative, though all members hold equal voting power.

# Leadership


# Appearance


# Lore


# Members
