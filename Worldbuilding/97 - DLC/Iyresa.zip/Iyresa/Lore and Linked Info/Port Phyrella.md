---
date: 2025-01-18
campaign: 
arc: 
type: location
aliases: 
---
# Description
- A port in the northeast of the [[Coast of Iyresa]].
- This port holds a reputation for being one of the biggest ports in the world, as [[Coast of Iyresa|Iyresa]] is a country that frequents many visitors and acts as a trade hub.
- The port is able dock over 1000 boats, making it very accessible. The country charges visitors no parking fees for short stays, making it a very popular spot to dock for quick visits and dropping off wares.

# Location
- A port on the northeast [[Coast of Iyresa]]. 

# Plot


# Key Locations
- Travelling merchant's ship that appears once a week, who provides valuable information/materials. (Xur from Destiny?)

# History


# Adventuring Hooks
- Suspicious Smuggling Operations: Smugglers from other nations seek to sell banned items, relics, and substances, which leads to disruptions in the cities of [[Stonefall]] and [[Cascadea]]. However, this operation seems to be planned by another nation to be able to take advantage of the [[Coast of Iyresa]] while it is dealing with this internal crises. 
- Shipwreck survivors: A damaged ship from the unknown arrives and the survivors claim to have ran into an undiscovered island with many dangers but also bountiful treasures. 
- Pirate attack: Pirates arrive from hostile nations and hold other ships ransom, otherwise the ships and the valuables on them will be destroyed.
- Rebellion Brewing: Revolutionaries of [[Coast of Iyresa|Iyresa]] use the port to smuggle weapons and rally support, threatening the stability of the city.