---
date: 2025-01-21
campaign: 
arc: 
type: Faction
aliases: 
alingment: 
---
# Summary
- A prestigious merchant guild headquartered in [[Cascadea]], controlling trade routes across the [[Black Tides]] and offering high-class auctions of rare artifacts, magical items, and exotic goods in the Velvet [[Drift]].

# Leadership


# Appearance


# Lore


# Members